@echo off
start "" "%~dp0DijahsDelightsCandyRun.exe" --path "%~dp0game_data"
